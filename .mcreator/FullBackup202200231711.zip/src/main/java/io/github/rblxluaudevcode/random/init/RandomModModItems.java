
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package io.github.rblxluaudevcode.random.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;

import io.github.rblxluaudevcode.random.RandomModMod;

public class RandomModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, RandomModMod.MODID);
	public static final RegistryObject<Item> FRIENDLY_ZOMBIE = REGISTRY.register("friendly_zombie_spawn_egg",
			() -> new ForgeSpawnEggItem(RandomModModEntities.FRIENDLY_ZOMBIE, -13395712, -13434676,
					new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
}
