
package io.github.rblxluaudevcode.random.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import io.github.rblxluaudevcode.random.entity.FriendlyZombieEntity;
import io.github.rblxluaudevcode.random.client.model.ModelzombieModel;

public class FriendlyZombieRenderer extends MobRenderer<FriendlyZombieEntity, ModelzombieModel<FriendlyZombieEntity>> {
	public FriendlyZombieRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelzombieModel(context.bakeLayer(ModelzombieModel.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(FriendlyZombieEntity entity) {
		return new ResourceLocation("random_mod:textures/entities/friendly_zombie.png");
	}
}
